<?php

namespace Illuminate\Cache;

use Illuminate\Cache\Events\CacheFlushed;
use Illuminate\Cache\Events\CacheFlushing;
use Illuminate\Cache\Events\RetrievingKey;
use Illuminate\Redis\Connections\PhpRedisClusterConnection;
use Illuminate\Redis\Connections\PhpRedisConnection;
use Illuminate\Redis\Connections\PredisClusterConnection;
use Illuminate\Redis\Connections\PredisConnection;
use Illuminate\Support\Collection;

use function Illuminate\Support\enum_value;

class RedisTaggedCache extends TaggedCache
{
    /**
     * Retrieve multiple items from the cache by key.
     *
     * Items not found in the cache will have a null value.
     *
     * @param  array  $keys
     * @return array
     */
    public function many(array $keys)
    {
        $defaults = (new Collection($keys))
            ->mapWithKeys(fn ($value, $key) => [is_string($key) ? $key : enum_value($value) => is_string($key) ? $value : null])
            ->all();

        $taggedKeys = [];

        foreach (array_keys($defaults) as $key) {
            $this->event(new RetrievingKey($this->getName(), $key));

            $taggedKeys[$key] = $this->itemKey($key);
        }

        $values = $this->store->manyViaPipeline(array_values($taggedKeys));

        $results = [];

        foreach ($taggedKeys as $key => $taggedKey) {
            $results[$key] = $this->handleManyResult($defaults, $key, $values[$taggedKey] ?? null);
        }

        return $results;
    }

    /**
     * Store an item in the cache if the key does not exist.
     *
     * @param  \UnitEnum|string  $key
     * @param  mixed  $value
     * @param  \DateTimeInterface|\DateInterval|int|null  $ttl
     * @return bool
     */
    public function add($key, $value, $ttl = null)
    {
        $key = enum_value($key);

        $seconds = null;

        if ($ttl !== null) {
            $seconds = $this->getSeconds($ttl);
        }

        $result = parent::add($key, $value, $ttl);

        if ($result && $seconds > 0 && method_exists($this->store, 'add')) {
            $this->tags->addEntry(
                $this->itemKey($key),
                $seconds
            );
        }

        return $result;
    }

    /**
     * Store an item in the cache.
     *
     * @param  \UnitEnum|string  $key
     * @param  mixed  $value
     * @param  \DateTimeInterface|\DateInterval|int|null  $ttl
     * @return bool
     */
    public function put($key, $value, $ttl = null)
    {
        $key = enum_value($key);

        if (is_null($ttl)) {
            return $this->forever($key, $value);
        }

        $seconds = $this->getSeconds($ttl);

        $result = parent::put($key, $value, $ttl);

        if ($result && $seconds > 0) {
            $this->tags->addEntry(
                $this->itemKey($key),
                $seconds
            );
        }

        return $result;
    }

    /**
     * Set the expiration of a cached item.
     *
     * @param  \UnitEnum|string  $key
     * @param  \DateTimeInterface|\DateInterval|int  $ttl
     * @return bool
     */
    public function touch($key, $ttl)
    {
        $key = enum_value($key);

        $seconds = $this->getSeconds($ttl);

        $result = parent::touch($key, $ttl);

        if ($result && $seconds > 0) {
            $this->tags->addEntry(
                $this->itemKey($key),
                $seconds
            );
        }

        return $result;
    }

    /**
     * Increment the value of an item in the cache.
     *
     * @param  \UnitEnum|string  $key
     * @param  mixed  $value
     * @return int|bool
     */
    public function increment($key, $value = 1)
    {
        $key = enum_value($key);

        $result = parent::increment($key, $value);

        if ($result !== false) {
            $this->tags->addEntry($this->itemKey($key), updateWhen: 'NX');
        }

        return $result;
    }

    /**
     * Decrement the value of an item in the cache.
     *
     * @param  \UnitEnum|string  $key
     * @param  mixed  $value
     * @return int|bool
     */
    public function decrement($key, $value = 1)
    {
        $key = enum_value($key);

        $result = parent::decrement($key, $value);

        if ($result !== false) {
            $this->tags->addEntry($this->itemKey($key), updateWhen: 'NX');
        }

        return $result;
    }

    /**
     * Store an item in the cache indefinitely.
     *
     * @param  \UnitEnum|string  $key
     * @param  mixed  $value
     * @return bool
     */
    public function forever($key, $value)
    {
        $key = enum_value($key);

        $result = parent::forever($key, $value);

        if ($result) {
            $this->tags->addEntry($this->itemKey($key));
        }

        return $result;
    }

    /**
     * Remove all items from the cache.
     *
     * @return bool
     */
    public function flush()
    {
        $connection = $this->store->connection();

        if ($connection instanceof PredisClusterConnection ||
            $connection instanceof PhpRedisClusterConnection) {
            return $this->flushClusteredConnection();
        }

        $this->event(new CacheFlushing($this->getName()));

        $redisPrefix = match (true) {
            $connection instanceof PhpRedisConnection => $connection->client()->getOption(\Redis::OPT_PREFIX),
            $connection instanceof PredisConnection => $connection->client()->getOptions()->prefix,
        };

        $cachePrefix = $redisPrefix.$this->store->getPrefix();

        $script = <<<'LUA'
            local prefix = table.remove(ARGV, 1)

            for i, key in ipairs(KEYS) do
                redis.call('DEL', key)

                for j, arg in ipairs(ARGV) do
                    local zkey = string.gsub(key, prefix, "")
                    redis.call('ZREM', arg, zkey)
                end
            end
        LUA;

        $prefix = $this->store->getPrefix();

        foreach ($this->tags->getNames() as $name) {
            $entries = (new RedisTagSet($this->store, [$name]))->entries()
                ->map(fn (string $key) => $prefix.$key)
                ->chunk(1000);

            foreach ($entries as $keysToBeDeleted) {
                $connection->eval(
                    $script,
                    count($keysToBeDeleted),
                    ...$keysToBeDeleted,
                    ...[str_replace('-', '%-', $cachePrefix), $cachePrefix.$this->tags->tagId($name)]
                );
            }
        }

        $this->event(new CacheFlushed($this->getName()));

        return true;
    }

    /**
     * Remove all items from the cache.
     *
     * @return bool
     */
    protected function flushClusteredConnection()
    {
        $this->event(new CacheFlushing($this->getName()));

        $this->flushValues();
        $this->tags->flush();

        $this->event(new CacheFlushed($this->getName()));

        return true;
    }

    /**
     * Flush the individual cache entries for the tags.
     *
     * @return void
     */
    protected function flushValues()
    {
        $prefix = $this->store->getPrefix();

        $entries = $this->tags->entries()
            ->map(fn (string $key) => $prefix.$key)
            ->chunk(1000);

        $connection = $this->store->connection();

        foreach ($entries as $cacheKeys) {
            if ($connection instanceof PredisClusterConnection) {
                $connection->pipeline(function ($connection) use ($cacheKeys) {
                    foreach ($cacheKeys as $cacheKey) {
                        $connection->del($cacheKey);
                    }
                });
            } else {
                $connection->del(...$cacheKeys);
            }
        }
    }

    /**
     * Remove all stale reference entries from the tag set.
     *
     * @return bool
     */
    public function flushStale()
    {
        $this->tags->flushStaleEntries();

        return true;
    }
}
